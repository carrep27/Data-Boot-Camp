
## WeatherPy


```python
# Dependencies
import openweathermapy.core as owm
import pandas as pd
import numpy as np
import random
from citipy import citipy 
import matplotlib.pyplot as plt
import requests
import time
from config import apikey
```

## Gather Data


```python
#Get random coordinates using import random. Latitude runs from 0 to 90 so we are asking for range +-90. Longtitude runs from
# 0 to 180 so we are asking for range +-180. 

#create empty lists we will append to
Latitude = []
Longitude = []
for x in range(0,1500):
    Latitude.append(random.uniform(-90,90))
    Longitude.append(random.uniform(-180,180))

#create dataframe for the latitude and longitude data we just collected. 

Cities = pd.DataFrame(columns = ["Latitude","Longitude"])
Cities["Latitude"] = Latitude
Cities["Longitude"] = Longitude
```


```python
#Use Citiypy to get City closest to Coordinates

#create empty list we will append City name to
Cities1 =[]

#use iterrow to loop through Latitude and Longitude from DataFrame "Cities" we just created to get nearest city
for index, row in Cities.iterrows():
    City=citipy.nearest_city(row["Latitude"],row["Longitude"])
    Cities1.append(City.city_name)

#add the list of cities to the dataframe which already contains our Latitude and Longitude
Cities["City"]=Cities1
```


```python
#remove any duplicate cities so only unique values. This is why we chose 1500 sets of random numbers....so that when 
#dupliates are elminated, we are left with at least 500 unique cities

new_data = Cities.drop_duplicates("City",keep="first")
print("We have " + str(len(new_data)) + " cities.")

# new_data
```

    We have 618 cities.
    


```python
#Utilize openweathermap api to get climate conditions at each city

units = "Imperial"
appid = apikey
url = "http://api.openweathermap.org/data/2.5/weather?"
query_url = f"{url}appid={apikey}&units={units}&q=" 


#create empty lists what we will append to with each API pull and set a city counter to 0
counter = 0
Temp = []
C = []
LTTE = []
LNGE = []
HUM = []
CL = []
WS = []


# Loop through the list of cities and perform a request for data on each
# because CityPy can return a City name that openweathermap might not recongize (for whatever reason), we utilize try/except

for index,row in new_data.iterrows():
    counter = counter + 1
    x=row["City"]
    q_url = query_url + str(x)
    response = requests.get(q_url).json()
    try:
        print(f"City #{counter}.") #print the # the city holds in our list (aka where we are in the loop)
        print(f"City name is {x} and its url is {q_url}.") #print the api url
        print("The City ID is " + str(response["id"]) + ".") #print the city id
        Temp.append(response['main']['temp']) #get the Temp (will be in farenheit cause we declared Imperial units)
        LNGE.append(response["coord"]["lon"]) #get Longitude
        LTTE.append(response["coord"]["lat"]) #get Latitue
        C.append(response["name"]) # get City Name
        HUM.append(response["main"]["humidity"]) #get Humidity
        CL.append(response["clouds"]["all"]) #get Cloudiness
        WS.append(response["wind"]["speed"]) #get WindSpeed (will be in mph cause we declared units Imperial)                       
    except: #if openweathermap cannot find a city, the city will be skipped and the message below will be prints
        print("This is not a city recognized in OpenWeatherMap.There will be no data for this city")
        pass
    print("------------------------------------------------------------------------------------")

#after cycling through the data, create a new data frame that contains all the info we just gathered and appended into lists
#first the dataframe and one column is created, and then each subsequent column is added
citydata=pd.DataFrame(columns = ["City"])

citydata["City"] = C
citydata["Longtitude"] = LNGE
citydata["Latitude"]=LTTE
citydata["Temperature"]= Temp
citydata["Humidity"] = HUM
citydata["Cloudiness"] = CL
citydata["Wind Speed"] = WS


```

    City #1.
    City name is amderma and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=amderma.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #2.
    City name is mataura and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mataura.
    The City ID is 6201424.
    ------------------------------------------------------------------------------------
    City #3.
    City name is jaciara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=jaciara.
    The City ID is 3460355.
    ------------------------------------------------------------------------------------
    City #4.
    City name is saint-philippe and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=saint-philippe.
    The City ID is 6138908.
    ------------------------------------------------------------------------------------
    City #5.
    City name is torbay and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=torbay.
    The City ID is 6167817.
    ------------------------------------------------------------------------------------
    City #6.
    City name is taolanaro and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=taolanaro.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #7.
    City name is victoria and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=victoria.
    The City ID is 1733782.
    ------------------------------------------------------------------------------------
    City #8.
    City name is bluff and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bluff.
    The City ID is 2175403.
    ------------------------------------------------------------------------------------
    City #9.
    City name is ushuaia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ushuaia.
    The City ID is 3833367.
    ------------------------------------------------------------------------------------
    City #10.
    City name is jibuti and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=jibuti.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #11.
    City name is kovur and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kovur.
    The City ID is 1265888.
    ------------------------------------------------------------------------------------
    City #12.
    City name is kamenka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kamenka.
    The City ID is 553725.
    ------------------------------------------------------------------------------------
    City #13.
    City name is trudarmeyskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=trudarmeyskiy.
    The City ID is 1489167.
    ------------------------------------------------------------------------------------
    City #14.
    City name is hilo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hilo.
    The City ID is 5855927.
    ------------------------------------------------------------------------------------
    City #15.
    City name is samusu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=samusu.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #16.
    City name is tanda and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tanda.
    The City ID is 1273410.
    ------------------------------------------------------------------------------------
    City #17.
    City name is lagoa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lagoa.
    The City ID is 2267254.
    ------------------------------------------------------------------------------------
    City #18.
    City name is ulaangom and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ulaangom.
    The City ID is 1515029.
    ------------------------------------------------------------------------------------
    City #19.
    City name is ji-parana and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ji-parana.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #20.
    City name is esperance and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=esperance.
    The City ID is 3573739.
    ------------------------------------------------------------------------------------
    City #21.
    City name is moree and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=moree.
    The City ID is 2156927.
    ------------------------------------------------------------------------------------
    City #22.
    City name is vallentuna and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vallentuna.
    The City ID is 2665452.
    ------------------------------------------------------------------------------------
    City #23.
    City name is albany and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=albany.
    The City ID is 5106834.
    ------------------------------------------------------------------------------------
    City #24.
    City name is araguaina and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=araguaina.
    The City ID is 3407357.
    ------------------------------------------------------------------------------------
    City #25.
    City name is rikitea and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rikitea.
    The City ID is 4030556.
    ------------------------------------------------------------------------------------
    City #26.
    City name is vladimirskaya and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vladimirskaya.
    The City ID is 473166.
    ------------------------------------------------------------------------------------
    City #27.
    City name is hermanus and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hermanus.
    The City ID is 3366880.
    ------------------------------------------------------------------------------------
    City #28.
    City name is tuktoyaktuk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tuktoyaktuk.
    The City ID is 6170031.
    ------------------------------------------------------------------------------------
    City #29.
    City name is kodiak and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kodiak.
    The City ID is 4407665.
    ------------------------------------------------------------------------------------
    City #30.
    City name is golden and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=golden.
    The City ID is 5962582.
    ------------------------------------------------------------------------------------
    City #31.
    City name is jamestown and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=jamestown.
    The City ID is 2069194.
    ------------------------------------------------------------------------------------
    City #32.
    City name is champerico and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=champerico.
    The City ID is 3530097.
    ------------------------------------------------------------------------------------
    City #33.
    City name is touros and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=touros.
    The City ID is 3386213.
    ------------------------------------------------------------------------------------
    City #34.
    City name is hirara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hirara.
    The City ID is 1862505.
    ------------------------------------------------------------------------------------
    City #35.
    City name is tagusao and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tagusao.
    The City ID is 1684245.
    ------------------------------------------------------------------------------------
    City #36.
    City name is cape town and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=cape town.
    The City ID is 3369157.
    ------------------------------------------------------------------------------------
    City #37.
    City name is odesskoye and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=odesskoye.
    The City ID is 1496380.
    ------------------------------------------------------------------------------------
    City #38.
    City name is upernavik and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=upernavik.
    The City ID is 3418910.
    ------------------------------------------------------------------------------------
    City #39.
    City name is general roca and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=general roca.
    The City ID is 3855065.
    ------------------------------------------------------------------------------------
    City #40.
    City name is chokurdakh and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=chokurdakh.
    The City ID is 2126123.
    ------------------------------------------------------------------------------------
    City #41.
    City name is lompoc and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lompoc.
    The City ID is 5367788.
    ------------------------------------------------------------------------------------
    City #42.
    City name is fredericksburg and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fredericksburg.
    The City ID is 4760059.
    ------------------------------------------------------------------------------------
    City #43.
    City name is fiche and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fiche.
    The City ID is 337771.
    ------------------------------------------------------------------------------------
    City #44.
    City name is santa vitoria do palmar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=santa vitoria do palmar.
    The City ID is 3449747.
    ------------------------------------------------------------------------------------
    City #45.
    City name is barrow and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=barrow.
    The City ID is 3833859.
    ------------------------------------------------------------------------------------
    City #46.
    City name is san patricio and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=san patricio.
    The City ID is 3437029.
    ------------------------------------------------------------------------------------
    City #47.
    City name is balakhta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=balakhta.
    The City ID is 1510998.
    ------------------------------------------------------------------------------------
    City #48.
    City name is saint-pierre and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=saint-pierre.
    The City ID is 2995603.
    ------------------------------------------------------------------------------------
    City #49.
    City name is bang len and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bang len.
    The City ID is 1619415.
    ------------------------------------------------------------------------------------
    City #50.
    City name is coquimbo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=coquimbo.
    The City ID is 3893629.
    ------------------------------------------------------------------------------------
    City #51.
    City name is hlinsko and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hlinsko.
    The City ID is 3075766.
    ------------------------------------------------------------------------------------
    City #52.
    City name is busselton and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=busselton.
    The City ID is 2075265.
    ------------------------------------------------------------------------------------
    City #53.
    City name is aitape and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=aitape.
    The City ID is 2101169.
    ------------------------------------------------------------------------------------
    City #54.
    City name is krasnoselkup and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=krasnoselkup.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #55.
    City name is saint george and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=saint george.
    The City ID is 262462.
    ------------------------------------------------------------------------------------
    City #56.
    City name is tautira and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tautira.
    The City ID is 4033557.
    ------------------------------------------------------------------------------------
    City #57.
    City name is avarua and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=avarua.
    The City ID is 4035715.
    ------------------------------------------------------------------------------------
    City #58.
    City name is vaini and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vaini.
    The City ID is 1273574.
    ------------------------------------------------------------------------------------
    City #59.
    City name is puerto princesa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=puerto princesa.
    The City ID is 1692685.
    ------------------------------------------------------------------------------------
    City #60.
    City name is norman wells and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=norman wells.
    The City ID is 6089245.
    ------------------------------------------------------------------------------------
    City #61.
    City name is new norfolk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=new norfolk.
    The City ID is 2155415.
    ------------------------------------------------------------------------------------
    City #62.
    City name is tasiilaq and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tasiilaq.
    The City ID is 3424607.
    ------------------------------------------------------------------------------------
    City #63.
    City name is dicabisagan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dicabisagan.
    The City ID is 1715015.
    ------------------------------------------------------------------------------------
    City #64.
    City name is samarai and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=samarai.
    The City ID is 2132606.
    ------------------------------------------------------------------------------------
    City #65.
    City name is furtwangen and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=furtwangen.
    The City ID is 2834685.
    ------------------------------------------------------------------------------------
    City #66.
    City name is zhezkazgan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=zhezkazgan.
    The City ID is 1516589.
    ------------------------------------------------------------------------------------
    City #67.
    City name is general cepeda and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=general cepeda.
    The City ID is 4005870.
    ------------------------------------------------------------------------------------
    City #68.
    City name is muros and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=muros.
    The City ID is 3115824.
    ------------------------------------------------------------------------------------
    City #69.
    City name is vila velha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vila velha.
    The City ID is 6320062.
    ------------------------------------------------------------------------------------
    City #70.
    City name is illoqqortoormiut and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=illoqqortoormiut.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #71.
    City name is port lincoln and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=port lincoln.
    The City ID is 2063036.
    ------------------------------------------------------------------------------------
    City #72.
    City name is pevek and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pevek.
    The City ID is 2122090.
    ------------------------------------------------------------------------------------
    City #73.
    City name is kiunga and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kiunga.
    The City ID is 2093846.
    ------------------------------------------------------------------------------------
    City #74.
    City name is san policarpo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=san policarpo.
    The City ID is 1688696.
    ------------------------------------------------------------------------------------
    City #75.
    City name is tuscaloosa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tuscaloosa.
    The City ID is 4094455.
    ------------------------------------------------------------------------------------
    City #76.
    City name is kaeo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kaeo.
    The City ID is 2189343.
    ------------------------------------------------------------------------------------
    City #77.
    City name is kormilovka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kormilovka.
    The City ID is 1502526.
    ------------------------------------------------------------------------------------
    City #78.
    City name is vestmannaeyjar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vestmannaeyjar.
    The City ID is 3412093.
    ------------------------------------------------------------------------------------
    City #79.
    City name is iqaluit and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=iqaluit.
    The City ID is 5983720.
    ------------------------------------------------------------------------------------
    City #80.
    City name is severo-kurilsk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=severo-kurilsk.
    The City ID is 2121385.
    ------------------------------------------------------------------------------------
    City #81.
    City name is atuona and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=atuona.
    The City ID is 4020109.
    ------------------------------------------------------------------------------------
    City #82.
    City name is kapaa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kapaa.
    The City ID is 5848280.
    ------------------------------------------------------------------------------------
    City #83.
    City name is rawson and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rawson.
    The City ID is 3839307.
    ------------------------------------------------------------------------------------
    City #84.
    City name is airai and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=airai.
    The City ID is 1651810.
    ------------------------------------------------------------------------------------
    City #85.
    City name is bethel and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bethel.
    The City ID is 5880568.
    ------------------------------------------------------------------------------------
    City #86.
    City name is wanning and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=wanning.
    The City ID is 3220813.
    ------------------------------------------------------------------------------------
    City #87.
    City name is manggar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=manggar.
    The City ID is 1636426.
    ------------------------------------------------------------------------------------
    City #88.
    City name is ca mau and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ca mau.
    The City ID is 1586443.
    ------------------------------------------------------------------------------------
    City #89.
    City name is hamilton and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hamilton.
    The City ID is 3573197.
    ------------------------------------------------------------------------------------
    City #90.
    City name is aksu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=aksu.
    The City ID is 1524298.
    ------------------------------------------------------------------------------------
    City #91.
    City name is khatanga and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=khatanga.
    The City ID is 2022572.
    ------------------------------------------------------------------------------------
    City #92.
    City name is mar del plata and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mar del plata.
    The City ID is 3863379.
    ------------------------------------------------------------------------------------
    City #93.
    City name is chapais and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=chapais.
    The City ID is 5919850.
    ------------------------------------------------------------------------------------
    City #94.
    City name is saskylakh and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=saskylakh.
    The City ID is 2017155.
    ------------------------------------------------------------------------------------
    City #95.
    City name is marsabit and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=marsabit.
    The City ID is 187585.
    ------------------------------------------------------------------------------------
    City #96.
    City name is hobart and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hobart.
    The City ID is 2163355.
    ------------------------------------------------------------------------------------
    City #97.
    City name is lewistown and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lewistown.
    The City ID is 4899665.
    ------------------------------------------------------------------------------------
    City #98.
    City name is shiyan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=shiyan.
    The City ID is 1794903.
    ------------------------------------------------------------------------------------
    City #99.
    City name is kaitangata and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kaitangata.
    The City ID is 2208248.
    ------------------------------------------------------------------------------------
    City #100.
    City name is nemours and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nemours.
    The City ID is 2990793.
    ------------------------------------------------------------------------------------
    City #101.
    City name is bafia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bafia.
    The City ID is 2235194.
    ------------------------------------------------------------------------------------
    City #102.
    City name is roma and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=roma.
    The City ID is 6539761.
    ------------------------------------------------------------------------------------
    City #103.
    City name is manta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=manta.
    The City ID is 685981.
    ------------------------------------------------------------------------------------
    City #104.
    City name is ondorhaan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ondorhaan.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #105.
    City name is punta arenas and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=punta arenas.
    The City ID is 3874787.
    ------------------------------------------------------------------------------------
    City #106.
    City name is grindavik and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=grindavik.
    The City ID is 3416888.
    ------------------------------------------------------------------------------------
    City #107.
    City name is sao filipe and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sao filipe.
    The City ID is 3374210.
    ------------------------------------------------------------------------------------
    City #108.
    City name is ruatoria and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ruatoria.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #109.
    City name is butaritari and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=butaritari.
    The City ID is 2110227.
    ------------------------------------------------------------------------------------
    City #110.
    City name is joshimath and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=joshimath.
    The City ID is 1268814.
    ------------------------------------------------------------------------------------
    City #111.
    City name is faanui and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=faanui.
    The City ID is 4034551.
    ------------------------------------------------------------------------------------
    City #112.
    City name is tarko-sale and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tarko-sale.
    The City ID is 1490085.
    ------------------------------------------------------------------------------------
    City #113.
    City name is port alfred and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=port alfred.
    The City ID is 964432.
    ------------------------------------------------------------------------------------
    City #114.
    City name is luderitz and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=luderitz.
    The City ID is 3355672.
    ------------------------------------------------------------------------------------
    City #115.
    City name is rawah and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rawah.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #116.
    City name is pangnirtung and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pangnirtung.
    The City ID is 6096551.
    ------------------------------------------------------------------------------------
    City #117.
    City name is east london and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=east london.
    The City ID is 1006984.
    ------------------------------------------------------------------------------------
    City #118.
    City name is husavik and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=husavik.
    The City ID is 5961417.
    ------------------------------------------------------------------------------------
    City #119.
    City name is kruisfontein and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kruisfontein.
    The City ID is 986717.
    ------------------------------------------------------------------------------------
    City #120.
    City name is takoradi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=takoradi.
    The City ID is 2294915.
    ------------------------------------------------------------------------------------
    City #121.
    City name is poum and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=poum.
    The City ID is 787487.
    ------------------------------------------------------------------------------------
    City #122.
    City name is nikolskoye and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nikolskoye.
    The City ID is 546105.
    ------------------------------------------------------------------------------------
    City #123.
    City name is constitucion and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=constitucion.
    The City ID is 4011743.
    ------------------------------------------------------------------------------------
    City #124.
    City name is abha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=abha.
    The City ID is 110690.
    ------------------------------------------------------------------------------------
    City #125.
    City name is alice springs and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=alice springs.
    The City ID is 2077895.
    ------------------------------------------------------------------------------------
    City #126.
    City name is itarema and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=itarema.
    The City ID is 3393692.
    ------------------------------------------------------------------------------------
    City #127.
    City name is sitka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sitka.
    The City ID is 4267710.
    ------------------------------------------------------------------------------------
    City #128.
    City name is pisco and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pisco.
    The City ID is 3932145.
    ------------------------------------------------------------------------------------
    City #129.
    City name is bredasdorp and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bredasdorp.
    The City ID is 1015776.
    ------------------------------------------------------------------------------------
    City #130.
    City name is hithadhoo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hithadhoo.
    The City ID is 1282256.
    ------------------------------------------------------------------------------------
    City #131.
    City name is sola and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sola.
    The City ID is 643453.
    ------------------------------------------------------------------------------------
    City #132.
    City name is aklavik and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=aklavik.
    The City ID is 5882953.
    ------------------------------------------------------------------------------------
    City #133.
    City name is mehamn and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mehamn.
    The City ID is 778707.
    ------------------------------------------------------------------------------------
    City #134.
    City name is ko samui and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ko samui.
    The City ID is 1154689.
    ------------------------------------------------------------------------------------
    City #135.
    City name is qaanaaq and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=qaanaaq.
    The City ID is 3831208.
    ------------------------------------------------------------------------------------
    City #136.
    City name is sharlyk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sharlyk.
    The City ID is 495670.
    ------------------------------------------------------------------------------------
    City #137.
    City name is laguna and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=laguna.
    The City ID is 4013704.
    ------------------------------------------------------------------------------------
    City #138.
    City name is komsomolskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=komsomolskiy.
    The City ID is 1486910.
    ------------------------------------------------------------------------------------
    City #139.
    City name is russell and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=russell.
    The City ID is 3844421.
    ------------------------------------------------------------------------------------
    City #140.
    City name is tilichiki and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tilichiki.
    The City ID is 2120591.
    ------------------------------------------------------------------------------------
    City #141.
    City name is ancud and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ancud.
    The City ID is 3899695.
    ------------------------------------------------------------------------------------
    City #142.
    City name is nishihara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nishihara.
    The City ID is 1850144.
    ------------------------------------------------------------------------------------
    City #143.
    City name is arraial do cabo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=arraial do cabo.
    The City ID is 3471451.
    ------------------------------------------------------------------------------------
    City #144.
    City name is krechevitsy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=krechevitsy.
    The City ID is 541256.
    ------------------------------------------------------------------------------------
    City #145.
    City name is flin flon and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=flin flon.
    The City ID is 5954718.
    ------------------------------------------------------------------------------------
    City #146.
    City name is kosa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kosa.
    The City ID is 544318.
    ------------------------------------------------------------------------------------
    City #147.
    City name is caohai and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=caohai.
    The City ID is 1816028.
    ------------------------------------------------------------------------------------
    City #148.
    City name is wanaka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=wanaka.
    The City ID is 2184707.
    ------------------------------------------------------------------------------------
    City #149.
    City name is beloha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=beloha.
    The City ID is 1067565.
    ------------------------------------------------------------------------------------
    City #150.
    City name is port elizabeth and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=port elizabeth.
    The City ID is 4501427.
    ------------------------------------------------------------------------------------
    City #151.
    City name is sorland and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sorland.
    The City ID is 3137469.
    ------------------------------------------------------------------------------------
    City #152.
    City name is leticia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=leticia.
    The City ID is 3676623.
    ------------------------------------------------------------------------------------
    City #153.
    City name is cidreira and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=cidreira.
    The City ID is 3466165.
    ------------------------------------------------------------------------------------
    City #154.
    City name is burica and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=burica.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #155.
    City name is challakere and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=challakere.
    The City ID is 1274862.
    ------------------------------------------------------------------------------------
    City #156.
    City name is georgetown and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=georgetown.
    The City ID is 3378644.
    ------------------------------------------------------------------------------------
    City #157.
    City name is castro and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=castro.
    The City ID is 3896218.
    ------------------------------------------------------------------------------------
    City #158.
    City name is bafq and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bafq.
    The City ID is 142255.
    ------------------------------------------------------------------------------------
    City #159.
    City name is thompson and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=thompson.
    The City ID is 6165406.
    ------------------------------------------------------------------------------------
    City #160.
    City name is ribeira grande and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ribeira grande.
    The City ID is 3372707.
    ------------------------------------------------------------------------------------
    City #161.
    City name is nouadhibou and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nouadhibou.
    The City ID is 2377457.
    ------------------------------------------------------------------------------------
    City #162.
    City name is inhambane and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=inhambane.
    The City ID is 1045114.
    ------------------------------------------------------------------------------------
    City #163.
    City name is novomyrhorod and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=novomyrhorod.
    The City ID is 699453.
    ------------------------------------------------------------------------------------
    City #164.
    City name is wonthaggi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=wonthaggi.
    The City ID is 2154826.
    ------------------------------------------------------------------------------------
    City #165.
    City name is saleaula and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=saleaula.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #166.
    City name is hasaki and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hasaki.
    The City ID is 2112802.
    ------------------------------------------------------------------------------------
    City #167.
    City name is narsaq and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=narsaq.
    The City ID is 3421719.
    ------------------------------------------------------------------------------------
    City #168.
    City name is harper and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=harper.
    The City ID is 4696310.
    ------------------------------------------------------------------------------------
    City #169.
    City name is fairbanks and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fairbanks.
    The City ID is 5861897.
    ------------------------------------------------------------------------------------
    City #170.
    City name is guerrero negro and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=guerrero negro.
    The City ID is 4021858.
    ------------------------------------------------------------------------------------
    City #171.
    City name is achalpur and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=achalpur.
    The City ID is 1279390.
    ------------------------------------------------------------------------------------
    City #172.
    City name is mingaora and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mingaora.
    The City ID is 1170395.
    ------------------------------------------------------------------------------------
    City #173.
    City name is san joaquin and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=san joaquin.
    The City ID is 1689597.
    ------------------------------------------------------------------------------------
    City #174.
    City name is puerto ayora and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=puerto ayora.
    The City ID is 3652764.
    ------------------------------------------------------------------------------------
    City #175.
    City name is pailitas and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pailitas.
    The City ID is 3673379.
    ------------------------------------------------------------------------------------
    City #176.
    City name is rongcheng and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rongcheng.
    The City ID is 1786855.
    ------------------------------------------------------------------------------------
    City #177.
    City name is druzhba and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=druzhba.
    The City ID is 691693.
    ------------------------------------------------------------------------------------
    City #178.
    City name is lima and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lima.
    The City ID is 3936456.
    ------------------------------------------------------------------------------------
    City #179.
    City name is mlonggo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mlonggo.
    The City ID is 1635164.
    ------------------------------------------------------------------------------------
    City #180.
    City name is ust-uda and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ust-uda.
    The City ID is 2013865.
    ------------------------------------------------------------------------------------
    City #181.
    City name is salekhard and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=salekhard.
    The City ID is 1493197.
    ------------------------------------------------------------------------------------
    City #182.
    City name is sambava and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sambava.
    The City ID is 1056899.
    ------------------------------------------------------------------------------------
    City #183.
    City name is salym and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=salym.
    The City ID is 1493162.
    ------------------------------------------------------------------------------------
    City #184.
    City name is tiksi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tiksi.
    The City ID is 2015306.
    ------------------------------------------------------------------------------------
    City #185.
    City name is paucartambo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=paucartambo.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #186.
    City name is dikson and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dikson.
    The City ID is 1507390.
    ------------------------------------------------------------------------------------
    City #187.
    City name is yuncheng and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=yuncheng.
    The City ID is 1785738.
    ------------------------------------------------------------------------------------
    City #188.
    City name is dehloran and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dehloran.
    The City ID is 136702.
    ------------------------------------------------------------------------------------
    City #189.
    City name is yulara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=yulara.
    The City ID is 6355222.
    ------------------------------------------------------------------------------------
    City #190.
    City name is sinazongwe and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sinazongwe.
    The City ID is 897456.
    ------------------------------------------------------------------------------------
    City #191.
    City name is lebu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lebu.
    The City ID is 344979.
    ------------------------------------------------------------------------------------
    City #192.
    City name is anadyr and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=anadyr.
    The City ID is 2127202.
    ------------------------------------------------------------------------------------
    City #193.
    City name is yorkton and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=yorkton.
    The City ID is 6185607.
    ------------------------------------------------------------------------------------
    City #194.
    City name is simeonovgrad and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=simeonovgrad.
    The City ID is 727217.
    ------------------------------------------------------------------------------------
    City #195.
    City name is szczytno and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=szczytno.
    The City ID is 757357.
    ------------------------------------------------------------------------------------
    City #196.
    City name is mecca and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mecca.
    The City ID is 104515.
    ------------------------------------------------------------------------------------
    City #197.
    City name is beira and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=beira.
    The City ID is 3119841.
    ------------------------------------------------------------------------------------
    City #198.
    City name is najran and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=najran.
    The City ID is 103630.
    ------------------------------------------------------------------------------------
    City #199.
    City name is san cristobal and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=san cristobal.
    The City ID is 3652462.
    ------------------------------------------------------------------------------------
    City #200.
    City name is qaqortoq and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=qaqortoq.
    The City ID is 3420846.
    ------------------------------------------------------------------------------------
    City #201.
    City name is tura and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tura.
    The City ID is 1254046.
    ------------------------------------------------------------------------------------
    City #202.
    City name is youkounkoun and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=youkounkoun.
    The City ID is 2414055.
    ------------------------------------------------------------------------------------
    City #203.
    City name is santa rosa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=santa rosa.
    The City ID is 3835994.
    ------------------------------------------------------------------------------------
    City #204.
    City name is mayo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mayo.
    The City ID is 6068416.
    ------------------------------------------------------------------------------------
    City #205.
    City name is fredericton and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fredericton.
    The City ID is 5957776.
    ------------------------------------------------------------------------------------
    City #206.
    City name is quatre cocos and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=quatre cocos.
    The City ID is 1106643.
    ------------------------------------------------------------------------------------
    City #207.
    City name is lasa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lasa.
    The City ID is 146639.
    ------------------------------------------------------------------------------------
    City #208.
    City name is yumbel and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=yumbel.
    The City ID is 3867625.
    ------------------------------------------------------------------------------------
    City #209.
    City name is rungata and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rungata.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #210.
    City name is yar-sale and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=yar-sale.
    The City ID is 1486321.
    ------------------------------------------------------------------------------------
    City #211.
    City name is ann arbor and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ann arbor.
    The City ID is 4984247.
    ------------------------------------------------------------------------------------
    City #212.
    City name is aykhal and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=aykhal.
    The City ID is 2027296.
    ------------------------------------------------------------------------------------
    City #213.
    City name is kelvington and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kelvington.
    The City ID is 5990669.
    ------------------------------------------------------------------------------------
    City #214.
    City name is padang and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=padang.
    The City ID is 1633419.
    ------------------------------------------------------------------------------------
    City #215.
    City name is calvia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=calvia.
    The City ID is 2520493.
    ------------------------------------------------------------------------------------
    City #216.
    City name is arona and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=arona.
    The City ID is 3182812.
    ------------------------------------------------------------------------------------
    City #217.
    City name is pasni and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pasni.
    The City ID is 1168312.
    ------------------------------------------------------------------------------------
    City #218.
    City name is belushya guba and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=belushya guba.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #219.
    City name is saldanha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=saldanha.
    The City ID is 2737599.
    ------------------------------------------------------------------------------------
    City #220.
    City name is rocha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rocha.
    The City ID is 3440777.
    ------------------------------------------------------------------------------------
    City #221.
    City name is pangkalanbuun and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pangkalanbuun.
    The City ID is 1632694.
    ------------------------------------------------------------------------------------
    City #222.
    City name is coihaique and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=coihaique.
    The City ID is 3894426.
    ------------------------------------------------------------------------------------
    City #223.
    City name is mikun and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mikun.
    The City ID is 526600.
    ------------------------------------------------------------------------------------
    City #224.
    City name is jacareacanga and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=jacareacanga.
    The City ID is 3397763.
    ------------------------------------------------------------------------------------
    City #225.
    City name is keti bandar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=keti bandar.
    The City ID is 1174451.
    ------------------------------------------------------------------------------------
    City #226.
    City name is manali and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=manali.
    The City ID is 1263967.
    ------------------------------------------------------------------------------------
    City #227.
    City name is ilulissat and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ilulissat.
    The City ID is 3423146.
    ------------------------------------------------------------------------------------
    City #228.
    City name is nyurba and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nyurba.
    The City ID is 2018735.
    ------------------------------------------------------------------------------------
    City #229.
    City name is cabra and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=cabra.
    The City ID is 2520645.
    ------------------------------------------------------------------------------------
    City #230.
    City name is magadan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=magadan.
    The City ID is 2123628.
    ------------------------------------------------------------------------------------
    City #231.
    City name is mys shmidta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mys shmidta.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #232.
    City name is nador and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nador.
    The City ID is 2541479.
    ------------------------------------------------------------------------------------
    City #233.
    City name is tazovskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tazovskiy.
    The City ID is 1489853.
    ------------------------------------------------------------------------------------
    City #234.
    City name is kyaikto and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kyaikto.
    The City ID is 1317375.
    ------------------------------------------------------------------------------------
    City #235.
    City name is caluquembe and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=caluquembe.
    The City ID is 3351024.
    ------------------------------------------------------------------------------------
    City #236.
    City name is gubkinskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=gubkinskiy.
    The City ID is 1539209.
    ------------------------------------------------------------------------------------
    City #237.
    City name is ngukurr and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ngukurr.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #238.
    City name is san rafael and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=san rafael.
    The City ID is 3836669.
    ------------------------------------------------------------------------------------
    City #239.
    City name is quartucciu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=quartucciu.
    The City ID is 2523666.
    ------------------------------------------------------------------------------------
    City #240.
    City name is isangel and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=isangel.
    The City ID is 2136825.
    ------------------------------------------------------------------------------------
    City #241.
    City name is biak and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=biak.
    The City ID is 1637001.
    ------------------------------------------------------------------------------------
    City #242.
    City name is dingle and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dingle.
    The City ID is 1714733.
    ------------------------------------------------------------------------------------
    City #243.
    City name is kutum and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kutum.
    The City ID is 371745.
    ------------------------------------------------------------------------------------
    City #244.
    City name is cherskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=cherskiy.
    The City ID is 2126199.
    ------------------------------------------------------------------------------------
    City #245.
    City name is longyearbyen and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=longyearbyen.
    The City ID is 2729907.
    ------------------------------------------------------------------------------------
    City #246.
    City name is shadegan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=shadegan.
    The City ID is 116102.
    ------------------------------------------------------------------------------------
    City #247.
    City name is port augusta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=port augusta.
    The City ID is 2063056.
    ------------------------------------------------------------------------------------
    City #248.
    City name is talnakh and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=talnakh.
    The City ID is 1490256.
    ------------------------------------------------------------------------------------
    City #249.
    City name is lensk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lensk.
    The City ID is 2020838.
    ------------------------------------------------------------------------------------
    City #250.
    City name is ovalle and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ovalle.
    The City ID is 3877918.
    ------------------------------------------------------------------------------------
    City #251.
    City name is barentsburg and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=barentsburg.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #252.
    City name is carnarvon and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=carnarvon.
    The City ID is 1014034.
    ------------------------------------------------------------------------------------
    City #253.
    City name is vaitupu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vaitupu.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #254.
    City name is suileng and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=suileng.
    The City ID is 2034651.
    ------------------------------------------------------------------------------------
    City #255.
    City name is margate and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=margate.
    The City ID is 2158744.
    ------------------------------------------------------------------------------------
    City #256.
    City name is macomb and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=macomb.
    The City ID is 4900817.
    ------------------------------------------------------------------------------------
    City #257.
    City name is yarada and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=yarada.
    The City ID is 1252783.
    ------------------------------------------------------------------------------------
    City #258.
    City name is farafangana and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=farafangana.
    The City ID is 1065158.
    ------------------------------------------------------------------------------------
    City #259.
    City name is teguise and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=teguise.
    The City ID is 2510573.
    ------------------------------------------------------------------------------------
    City #260.
    City name is kushmurun and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kushmurun.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #261.
    City name is bathsheba and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bathsheba.
    The City ID is 3374083.
    ------------------------------------------------------------------------------------
    City #262.
    City name is bonavista and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bonavista.
    The City ID is 5905393.
    ------------------------------------------------------------------------------------
    City #263.
    City name is samalaeulu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=samalaeulu.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #264.
    City name is klaksvik and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=klaksvik.
    The City ID is 2618795.
    ------------------------------------------------------------------------------------
    City #265.
    City name is tsihombe and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tsihombe.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #266.
    City name is kumluca and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kumluca.
    The City ID is 305681.
    ------------------------------------------------------------------------------------
    City #267.
    City name is mendahara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mendahara.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #268.
    City name is cabo san lucas and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=cabo san lucas.
    The City ID is 3985710.
    ------------------------------------------------------------------------------------
    City #269.
    City name is provideniya and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=provideniya.
    The City ID is 4031574.
    ------------------------------------------------------------------------------------
    City #270.
    City name is arlit and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=arlit.
    The City ID is 2447513.
    ------------------------------------------------------------------------------------
    City #271.
    City name is opochka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=opochka.
    The City ID is 515155.
    ------------------------------------------------------------------------------------
    City #272.
    City name is el tigre and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=el tigre.
    The City ID is 3641351.
    ------------------------------------------------------------------------------------
    City #273.
    City name is clyde river and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=clyde river.
    The City ID is 5924351.
    ------------------------------------------------------------------------------------
    City #274.
    City name is louisbourg and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=louisbourg.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #275.
    City name is telford and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=telford.
    The City ID is 3345439.
    ------------------------------------------------------------------------------------
    City #276.
    City name is ponta do sol and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ponta do sol.
    The City ID is 3453439.
    ------------------------------------------------------------------------------------
    City #277.
    City name is arman and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=arman.
    The City ID is 2127060.
    ------------------------------------------------------------------------------------
    City #278.
    City name is kavieng and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kavieng.
    The City ID is 2094342.
    ------------------------------------------------------------------------------------
    City #279.
    City name is melilla and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=melilla.
    The City ID is 3659139.
    ------------------------------------------------------------------------------------
    City #280.
    City name is shinpokh and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=shinpokh.
    The City ID is 1165057.
    ------------------------------------------------------------------------------------
    City #281.
    City name is caravelas and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=caravelas.
    The City ID is 3466980.
    ------------------------------------------------------------------------------------
    City #282.
    City name is college and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=college.
    The City ID is 5859699.
    ------------------------------------------------------------------------------------
    City #283.
    City name is dukat and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dukat.
    The City ID is 786562.
    ------------------------------------------------------------------------------------
    City #284.
    City name is iisalmi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=iisalmi.
    The City ID is 656820.
    ------------------------------------------------------------------------------------
    City #285.
    City name is chirongui and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=chirongui.
    The City ID is 1090415.
    ------------------------------------------------------------------------------------
    City #286.
    City name is brae and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=brae.
    The City ID is 2654970.
    ------------------------------------------------------------------------------------
    City #287.
    City name is mayskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mayskiy.
    The City ID is 528248.
    ------------------------------------------------------------------------------------
    City #288.
    City name is standerton and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=standerton.
    The City ID is 952747.
    ------------------------------------------------------------------------------------
    City #289.
    City name is karonga and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=karonga.
    The City ID is 235715.
    ------------------------------------------------------------------------------------
    City #290.
    City name is codrington and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=codrington.
    The City ID is 2160063.
    ------------------------------------------------------------------------------------
    City #291.
    City name is camacha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=camacha.
    The City ID is 2270385.
    ------------------------------------------------------------------------------------
    City #292.
    City name is nome and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nome.
    The City ID is 4732862.
    ------------------------------------------------------------------------------------
    City #293.
    City name is scarborough and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=scarborough.
    The City ID is 2638419.
    ------------------------------------------------------------------------------------
    City #294.
    City name is trairi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=trairi.
    The City ID is 3386177.
    ------------------------------------------------------------------------------------
    City #295.
    City name is galle and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=galle.
    The City ID is 4695361.
    ------------------------------------------------------------------------------------
    City #296.
    City name is atar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=atar.
    The City ID is 2381334.
    ------------------------------------------------------------------------------------
    City #297.
    City name is kiama and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kiama.
    The City ID is 2161515.
    ------------------------------------------------------------------------------------
    City #298.
    City name is kalmar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kalmar.
    The City ID is 2702261.
    ------------------------------------------------------------------------------------
    City #299.
    City name is grand island and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=grand island.
    The City ID is 5069297.
    ------------------------------------------------------------------------------------
    City #300.
    City name is phalaborwa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=phalaborwa.
    The City ID is 965528.
    ------------------------------------------------------------------------------------
    City #301.
    City name is peleduy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=peleduy.
    The City ID is 2018069.
    ------------------------------------------------------------------------------------
    City #302.
    City name is falealupo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=falealupo.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #303.
    City name is nola and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nola.
    The City ID is 2383827.
    ------------------------------------------------------------------------------------
    City #304.
    City name is tabou and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tabou.
    The City ID is 2281120.
    ------------------------------------------------------------------------------------
    City #305.
    City name is harnosand and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=harnosand.
    The City ID is 2707684.
    ------------------------------------------------------------------------------------
    City #306.
    City name is roebourne and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=roebourne.
    The City ID is 2062276.
    ------------------------------------------------------------------------------------
    City #307.
    City name is vilhena and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vilhena.
    The City ID is 3924679.
    ------------------------------------------------------------------------------------
    City #308.
    City name is maracaibo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=maracaibo.
    The City ID is 3670764.
    ------------------------------------------------------------------------------------
    City #309.
    City name is rosetta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rosetta.
    The City ID is 350203.
    ------------------------------------------------------------------------------------
    City #310.
    City name is neiafu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=neiafu.
    The City ID is 4032420.
    ------------------------------------------------------------------------------------
    City #311.
    City name is bunia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bunia.
    The City ID is 217695.
    ------------------------------------------------------------------------------------
    City #312.
    City name is zhuhai and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=zhuhai.
    The City ID is 2052479.
    ------------------------------------------------------------------------------------
    City #313.
    City name is doha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=doha.
    The City ID is 290030.
    ------------------------------------------------------------------------------------
    City #314.
    City name is la palma and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=la palma.
    The City ID is 3687505.
    ------------------------------------------------------------------------------------
    City #315.
    City name is nerchinskiy zavod and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nerchinskiy zavod.
    The City ID is 2019323.
    ------------------------------------------------------------------------------------
    City #316.
    City name is omboue and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=omboue.
    The City ID is 2396853.
    ------------------------------------------------------------------------------------
    City #317.
    City name is fort nelson and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fort nelson.
    The City ID is 5955902.
    ------------------------------------------------------------------------------------
    City #318.
    City name is antigonish and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=antigonish.
    The City ID is 5886182.
    ------------------------------------------------------------------------------------
    City #319.
    City name is katsuura and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=katsuura.
    The City ID is 1865309.
    ------------------------------------------------------------------------------------
    City #320.
    City name is zarate and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=zarate.
    The City ID is 3932145.
    ------------------------------------------------------------------------------------
    City #321.
    City name is adet and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=adet.
    The City ID is 345353.
    ------------------------------------------------------------------------------------
    City #322.
    City name is lavrentiya and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lavrentiya.
    The City ID is 4031637.
    ------------------------------------------------------------------------------------
    City #323.
    City name is hofn and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hofn.
    The City ID is 2630299.
    ------------------------------------------------------------------------------------
    City #324.
    City name is ust-nera and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ust-nera.
    The City ID is 2120048.
    ------------------------------------------------------------------------------------
    City #325.
    City name is zhigansk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=zhigansk.
    The City ID is 2012530.
    ------------------------------------------------------------------------------------
    City #326.
    City name is kingston and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kingston.
    The City ID is 5992500.
    ------------------------------------------------------------------------------------
    City #327.
    City name is mahebourg and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mahebourg.
    The City ID is 934322.
    ------------------------------------------------------------------------------------
    City #328.
    City name is mirina and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mirina.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #329.
    City name is shingu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=shingu.
    The City ID is 1847947.
    ------------------------------------------------------------------------------------
    City #330.
    City name is inta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=inta.
    The City ID is 1505579.
    ------------------------------------------------------------------------------------
    City #331.
    City name is palabuhanratu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=palabuhanratu.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #332.
    City name is leiyang and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=leiyang.
    The City ID is 1804208.
    ------------------------------------------------------------------------------------
    City #333.
    City name is tsabong and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tsabong.
    The City ID is 932987.
    ------------------------------------------------------------------------------------
    City #334.
    City name is marquard and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=marquard.
    The City ID is 978677.
    ------------------------------------------------------------------------------------
    City #335.
    City name is zabaykalsk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=zabaykalsk.
    The City ID is 2012780.
    ------------------------------------------------------------------------------------
    City #336.
    City name is evans and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=evans.
    The City ID is 5576909.
    ------------------------------------------------------------------------------------
    City #337.
    City name is bengkulu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bengkulu.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #338.
    City name is whitehorse and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=whitehorse.
    The City ID is 6180550.
    ------------------------------------------------------------------------------------
    City #339.
    City name is kaseda and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kaseda.
    The City ID is 1859964.
    ------------------------------------------------------------------------------------
    City #340.
    City name is akcakoca and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=akcakoca.
    The City ID is 752584.
    ------------------------------------------------------------------------------------
    City #341.
    City name is varhaug and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=varhaug.
    The City ID is 3132644.
    ------------------------------------------------------------------------------------
    City #342.
    City name is ribeira brava and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ribeira brava.
    The City ID is 2263905.
    ------------------------------------------------------------------------------------
    City #343.
    City name is ziyang and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ziyang.
    The City ID is 1783683.
    ------------------------------------------------------------------------------------
    City #344.
    City name is salta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=salta.
    The City ID is 3838233.
    ------------------------------------------------------------------------------------
    City #345.
    City name is muli and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=muli.
    The City ID is 1256929.
    ------------------------------------------------------------------------------------
    City #346.
    City name is pavlodar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pavlodar.
    The City ID is 1520240.
    ------------------------------------------------------------------------------------
    City #347.
    City name is chuy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=chuy.
    The City ID is 3443061.
    ------------------------------------------------------------------------------------
    City #348.
    City name is milkovo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=milkovo.
    The City ID is 727030.
    ------------------------------------------------------------------------------------
    City #349.
    City name is kieta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kieta.
    The City ID is 2094027.
    ------------------------------------------------------------------------------------
    City #350.
    City name is leningradskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=leningradskiy.
    The City ID is 2123814.
    ------------------------------------------------------------------------------------
    City #351.
    City name is marovoay and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=marovoay.
    The City ID is 1059507.
    ------------------------------------------------------------------------------------
    City #352.
    City name is bolungarvik and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bolungarvik.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #353.
    City name is mayumba and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mayumba.
    The City ID is 2399001.
    ------------------------------------------------------------------------------------
    City #354.
    City name is araouane and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=araouane.
    The City ID is 2460954.
    ------------------------------------------------------------------------------------
    City #355.
    City name is zeya and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=zeya.
    The City ID is 2012593.
    ------------------------------------------------------------------------------------
    City #356.
    City name is ponta delgada and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ponta delgada.
    The City ID is 3372783.
    ------------------------------------------------------------------------------------
    City #357.
    City name is itoman and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=itoman.
    The City ID is 1861280.
    ------------------------------------------------------------------------------------
    City #358.
    City name is kismayo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kismayo.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #359.
    City name is thunder bay and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=thunder bay.
    The City ID is 6166142.
    ------------------------------------------------------------------------------------
    City #360.
    City name is tidore and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tidore.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #361.
    City name is souillac and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=souillac.
    The City ID is 3026644.
    ------------------------------------------------------------------------------------
    City #362.
    City name is alofi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=alofi.
    The City ID is 4036284.
    ------------------------------------------------------------------------------------
    City #363.
    City name is kavaratti and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kavaratti.
    The City ID is 1267390.
    ------------------------------------------------------------------------------------
    City #364.
    City name is huanren and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=huanren.
    The City ID is 2036713.
    ------------------------------------------------------------------------------------
    City #365.
    City name is ikongo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ikongo.
    The City ID is 1064234.
    ------------------------------------------------------------------------------------
    City #366.
    City name is innisfail and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=innisfail.
    The City ID is 5983430.
    ------------------------------------------------------------------------------------
    City #367.
    City name is eregli and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=eregli.
    The City ID is 315498.
    ------------------------------------------------------------------------------------
    City #368.
    City name is vredendal and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vredendal.
    The City ID is 3359736.
    ------------------------------------------------------------------------------------
    City #369.
    City name is dunedin and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dunedin.
    The City ID is 2191562.
    ------------------------------------------------------------------------------------
    City #370.
    City name is concepcion del oro and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=concepcion del oro.
    The City ID is 4013039.
    ------------------------------------------------------------------------------------
    City #371.
    City name is ystad and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ystad.
    The City ID is 2662149.
    ------------------------------------------------------------------------------------
    City #372.
    City name is macherla and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=macherla.
    The City ID is 1264647.
    ------------------------------------------------------------------------------------
    City #373.
    City name is leh and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=leh.
    The City ID is 1264976.
    ------------------------------------------------------------------------------------
    City #374.
    City name is fare and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fare.
    The City ID is 4034496.
    ------------------------------------------------------------------------------------
    City #375.
    City name is sakakah and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sakakah.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #376.
    City name is nizhneyansk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nizhneyansk.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #377.
    City name is baruun-urt and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=baruun-urt.
    The City ID is 2032614.
    ------------------------------------------------------------------------------------
    City #378.
    City name is merauke and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=merauke.
    The City ID is 2082539.
    ------------------------------------------------------------------------------------
    City #379.
    City name is bambous virieux and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bambous virieux.
    The City ID is 1106677.
    ------------------------------------------------------------------------------------
    City #380.
    City name is merritt island and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=merritt island.
    The City ID is 4164092.
    ------------------------------------------------------------------------------------
    City #381.
    City name is urdzhar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=urdzhar.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #382.
    City name is nara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nara.
    The City ID is 1855612.
    ------------------------------------------------------------------------------------
    City #383.
    City name is meulaboh and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=meulaboh.
    The City ID is 1214488.
    ------------------------------------------------------------------------------------
    City #384.
    City name is dudinka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dudinka.
    The City ID is 1507116.
    ------------------------------------------------------------------------------------
    City #385.
    City name is dingzhou and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dingzhou.
    The City ID is 1812728.
    ------------------------------------------------------------------------------------
    City #386.
    City name is ixcatepec and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ixcatepec.
    The City ID is 3526725.
    ------------------------------------------------------------------------------------
    City #387.
    City name is dobson and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dobson.
    The City ID is 4463810.
    ------------------------------------------------------------------------------------
    City #388.
    City name is iglino and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=iglino.
    The City ID is 557563.
    ------------------------------------------------------------------------------------
    City #389.
    City name is pecos and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pecos.
    The City ID is 5528182.
    ------------------------------------------------------------------------------------
    City #390.
    City name is bandarbeyla and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bandarbeyla.
    The City ID is 64814.
    ------------------------------------------------------------------------------------
    City #391.
    City name is madimba and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=madimba.
    The City ID is 2221046.
    ------------------------------------------------------------------------------------
    City #392.
    City name is maykain and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=maykain.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #393.
    City name is yellowknife and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=yellowknife.
    The City ID is 6185377.
    ------------------------------------------------------------------------------------
    City #394.
    City name is obera and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=obera.
    The City ID is 3430340.
    ------------------------------------------------------------------------------------
    City #395.
    City name is boras and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=boras.
    The City ID is 2720501.
    ------------------------------------------------------------------------------------
    City #396.
    City name is akureyri and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=akureyri.
    The City ID is 2633274.
    ------------------------------------------------------------------------------------
    City #397.
    City name is moyale and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=moyale.
    The City ID is 186180.
    ------------------------------------------------------------------------------------
    City #398.
    City name is vitim and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vitim.
    The City ID is 2013375.
    ------------------------------------------------------------------------------------
    City #399.
    City name is salinas and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=salinas.
    The City ID is 5391295.
    ------------------------------------------------------------------------------------
    City #400.
    City name is punta alta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=punta alta.
    The City ID is 3429886.
    ------------------------------------------------------------------------------------
    City #401.
    City name is bundaberg and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bundaberg.
    The City ID is 2173323.
    ------------------------------------------------------------------------------------
    City #402.
    City name is bilma and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bilma.
    The City ID is 2446796.
    ------------------------------------------------------------------------------------
    City #403.
    City name is lodja and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lodja.
    The City ID is 211647.
    ------------------------------------------------------------------------------------
    City #404.
    City name is tuatapere and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tuatapere.
    The City ID is 2180815.
    ------------------------------------------------------------------------------------
    City #405.
    City name is madison heights and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=madison heights.
    The City ID is 5000500.
    ------------------------------------------------------------------------------------
    City #406.
    City name is sandpoint and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sandpoint.
    The City ID is 5606401.
    ------------------------------------------------------------------------------------
    City #407.
    City name is cockburn harbour and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=cockburn harbour.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #408.
    City name is ondjiva and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ondjiva.
    The City ID is 3346821.
    ------------------------------------------------------------------------------------
    City #409.
    City name is labutta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=labutta.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #410.
    City name is hangal and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hangal.
    The City ID is 1270435.
    ------------------------------------------------------------------------------------
    City #411.
    City name is calvinia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=calvinia.
    The City ID is 3369174.
    ------------------------------------------------------------------------------------
    City #412.
    City name is baiyin and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=baiyin.
    The City ID is 1817240.
    ------------------------------------------------------------------------------------
    City #413.
    City name is balikpapan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=balikpapan.
    The City ID is 1650527.
    ------------------------------------------------------------------------------------
    City #414.
    City name is san jeronimo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=san jeronimo.
    The City ID is 3929607.
    ------------------------------------------------------------------------------------
    City #415.
    City name is jalu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=jalu.
    The City ID is 86049.
    ------------------------------------------------------------------------------------
    City #416.
    City name is pokrovsk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pokrovsk.
    The City ID is 704422.
    ------------------------------------------------------------------------------------
    City #417.
    City name is sabzevar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sabzevar.
    The City ID is 118063.
    ------------------------------------------------------------------------------------
    City #418.
    City name is deputatskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=deputatskiy.
    The City ID is 2028164.
    ------------------------------------------------------------------------------------
    City #419.
    City name is umm bab and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=umm bab.
    The City ID is 289548.
    ------------------------------------------------------------------------------------
    City #420.
    City name is verkhoyansk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=verkhoyansk.
    The City ID is 2013465.
    ------------------------------------------------------------------------------------
    City #421.
    City name is bacolod and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bacolod.
    The City ID is 1729564.
    ------------------------------------------------------------------------------------
    City #422.
    City name is moerai and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=moerai.
    The City ID is 4034188.
    ------------------------------------------------------------------------------------
    City #423.
    City name is birjand and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=birjand.
    The City ID is 140463.
    ------------------------------------------------------------------------------------
    City #424.
    City name is waldshut-tiengen and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=waldshut-tiengen.
    The City ID is 2814791.
    ------------------------------------------------------------------------------------
    City #425.
    City name is aswan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=aswan.
    The City ID is 359792.
    ------------------------------------------------------------------------------------
    City #426.
    City name is shkotovo-22 and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=shkotovo-22.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #427.
    City name is karaul and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=karaul.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #428.
    City name is ihosy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ihosy.
    The City ID is 1064275.
    ------------------------------------------------------------------------------------
    City #429.
    City name is lata and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lata.
    The City ID is 1253628.
    ------------------------------------------------------------------------------------
    City #430.
    City name is luanda and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=luanda.
    The City ID is 2240449.
    ------------------------------------------------------------------------------------
    City #431.
    City name is mount gambier and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mount gambier.
    The City ID is 2156643.
    ------------------------------------------------------------------------------------
    City #432.
    City name is geraldton and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=geraldton.
    The City ID is 5960603.
    ------------------------------------------------------------------------------------
    City #433.
    City name is petropavlovsk-kamchatskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=petropavlovsk-kamchatskiy.
    The City ID is 2122104.
    ------------------------------------------------------------------------------------
    City #434.
    City name is nieuw amsterdam and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nieuw amsterdam.
    The City ID is 3383434.
    ------------------------------------------------------------------------------------
    City #435.
    City name is okhotsk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=okhotsk.
    The City ID is 2122605.
    ------------------------------------------------------------------------------------
    City #436.
    City name is dondo and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dondo.
    The City ID is 1024696.
    ------------------------------------------------------------------------------------
    City #437.
    City name is alexandria and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=alexandria.
    The City ID is 4314550.
    ------------------------------------------------------------------------------------
    City #438.
    City name is marpod and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=marpod.
    The City ID is 686011.
    ------------------------------------------------------------------------------------
    City #439.
    City name is louis trichardt and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=louis trichardt.
    The City ID is 981827.
    ------------------------------------------------------------------------------------
    City #440.
    City name is vrangel and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vrangel.
    The City ID is 2013258.
    ------------------------------------------------------------------------------------
    City #441.
    City name is pokhara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pokhara.
    The City ID is 1282898.
    ------------------------------------------------------------------------------------
    City #442.
    City name is sentyabrskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sentyabrskiy.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #443.
    City name is dabola and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dabola.
    The City ID is 2422442.
    ------------------------------------------------------------------------------------
    City #444.
    City name is aripuana and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=aripuana.
    The City ID is 3665202.
    ------------------------------------------------------------------------------------
    City #445.
    City name is krutikha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=krutikha.
    The City ID is 1501706.
    ------------------------------------------------------------------------------------
    City #446.
    City name is mandalgovi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mandalgovi.
    The City ID is 2030065.
    ------------------------------------------------------------------------------------
    City #447.
    City name is adana and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=adana.
    The City ID is 325361.
    ------------------------------------------------------------------------------------
    City #448.
    City name is lokot and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lokot.
    The City ID is 534413.
    ------------------------------------------------------------------------------------
    City #449.
    City name is broome and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=broome.
    The City ID is 2656067.
    ------------------------------------------------------------------------------------
    City #450.
    City name is korla and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=korla.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #451.
    City name is matagami and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=matagami.
    The City ID is 2335713.
    ------------------------------------------------------------------------------------
    City #452.
    City name is rampura and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rampura.
    The City ID is 1258592.
    ------------------------------------------------------------------------------------
    City #453.
    City name is esmeraldas and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=esmeraldas.
    The City ID is 3464008.
    ------------------------------------------------------------------------------------
    City #454.
    City name is nemuro and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nemuro.
    The City ID is 2128975.
    ------------------------------------------------------------------------------------
    City #455.
    City name is anloga and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=anloga.
    The City ID is 2304548.
    ------------------------------------------------------------------------------------
    City #456.
    City name is ieud and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ieud.
    The City ID is 675721.
    ------------------------------------------------------------------------------------
    City #457.
    City name is sibolga and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sibolga.
    The City ID is 1213855.
    ------------------------------------------------------------------------------------
    City #458.
    City name is qandahar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=qandahar.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #459.
    City name is adrar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=adrar.
    The City ID is 2508813.
    ------------------------------------------------------------------------------------
    City #460.
    City name is berlevag and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=berlevag.
    The City ID is 780687.
    ------------------------------------------------------------------------------------
    City #461.
    City name is muzquiz and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=muzquiz.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #462.
    City name is chara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=chara.
    The City ID is 262462.
    ------------------------------------------------------------------------------------
    City #463.
    City name is tumannyy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tumannyy.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #464.
    City name is toliary and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=toliary.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #465.
    City name is tessalit and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tessalit.
    The City ID is 2449893.
    ------------------------------------------------------------------------------------
    City #466.
    City name is valera and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=valera.
    The City ID is 3625542.
    ------------------------------------------------------------------------------------
    City #467.
    City name is kampot and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kampot.
    The City ID is 1831112.
    ------------------------------------------------------------------------------------
    City #468.
    City name is bereda and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bereda.
    The City ID is 3105522.
    ------------------------------------------------------------------------------------
    City #469.
    City name is south river and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=south river.
    The City ID is 5895424.
    ------------------------------------------------------------------------------------
    City #470.
    City name is lalmohan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lalmohan.
    The City ID is 1185251.
    ------------------------------------------------------------------------------------
    City #471.
    City name is muborak and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=muborak.
    The City ID is 1216475.
    ------------------------------------------------------------------------------------
    City #472.
    City name is polunochnoye and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=polunochnoye.
    The City ID is 1494482.
    ------------------------------------------------------------------------------------
    City #473.
    City name is minab and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=minab.
    The City ID is 123941.
    ------------------------------------------------------------------------------------
    City #474.
    City name is onguday and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=onguday.
    The City ID is 1496130.
    ------------------------------------------------------------------------------------
    City #475.
    City name is mahon and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mahon.
    The City ID is 2965139.
    ------------------------------------------------------------------------------------
    City #476.
    City name is haibowan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=haibowan.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #477.
    City name is fallon and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fallon.
    The City ID is 5681948.
    ------------------------------------------------------------------------------------
    City #478.
    City name is pak chong and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pak chong.
    The City ID is 1608057.
    ------------------------------------------------------------------------------------
    City #479.
    City name is alcudia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=alcudia.
    The City ID is 2522091.
    ------------------------------------------------------------------------------------
    City #480.
    City name is rio tuba and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rio tuba.
    The City ID is 1691703.
    ------------------------------------------------------------------------------------
    City #481.
    City name is emilio carranza and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=emilio carranza.
    The City ID is 3514843.
    ------------------------------------------------------------------------------------
    City #482.
    City name is severnyy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=severnyy.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #483.
    City name is kaspiyskiy and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kaspiyskiy.
    The City ID is 551846.
    ------------------------------------------------------------------------------------
    City #484.
    City name is verkhnyaya maksakovka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=verkhnyaya maksakovka.
    The City ID is 474603.
    ------------------------------------------------------------------------------------
    City #485.
    City name is hami and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hami.
    The City ID is 1529484.
    ------------------------------------------------------------------------------------
    City #486.
    City name is tommot and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tommot.
    The City ID is 2015179.
    ------------------------------------------------------------------------------------
    City #487.
    City name is luganville and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=luganville.
    The City ID is 2136150.
    ------------------------------------------------------------------------------------
    City #488.
    City name is tabiauea and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tabiauea.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #489.
    City name is roros and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=roros.
    The City ID is 3141332.
    ------------------------------------------------------------------------------------
    City #490.
    City name is schertz and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=schertz.
    The City ID is 4727326.
    ------------------------------------------------------------------------------------
    City #491.
    City name is prince rupert and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=prince rupert.
    The City ID is 6113406.
    ------------------------------------------------------------------------------------
    City #492.
    City name is sao geraldo do araguaia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sao geraldo do araguaia.
    The City ID is 3388760.
    ------------------------------------------------------------------------------------
    City #493.
    City name is terney and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=terney.
    The City ID is 2015352.
    ------------------------------------------------------------------------------------
    City #494.
    City name is cootamundra and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=cootamundra.
    The City ID is 2170430.
    ------------------------------------------------------------------------------------
    City #495.
    City name is lakes entrance and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=lakes entrance.
    The City ID is 2160735.
    ------------------------------------------------------------------------------------
    City #496.
    City name is oriximina and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=oriximina.
    The City ID is 3393471.
    ------------------------------------------------------------------------------------
    City #497.
    City name is pozoblanco and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pozoblanco.
    The City ID is 2512340.
    ------------------------------------------------------------------------------------
    City #498.
    City name is vostok and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vostok.
    The City ID is 2013279.
    ------------------------------------------------------------------------------------
    City #499.
    City name is superior and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=superior.
    The City ID is 5440838.
    ------------------------------------------------------------------------------------
    City #500.
    City name is christchurch and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=christchurch.
    The City ID is 2192362.
    ------------------------------------------------------------------------------------
    City #501.
    City name is zmievka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=zmievka.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #502.
    City name is shenjiamen and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=shenjiamen.
    The City ID is 1795632.
    ------------------------------------------------------------------------------------
    City #503.
    City name is port blair and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=port blair.
    The City ID is 1259385.
    ------------------------------------------------------------------------------------
    City #504.
    City name is soloneshnoye and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=soloneshnoye.
    The City ID is 1491461.
    ------------------------------------------------------------------------------------
    City #505.
    City name is rapid valley and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rapid valley.
    The City ID is 5768244.
    ------------------------------------------------------------------------------------
    City #506.
    City name is kamenskoye and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kamenskoye.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #507.
    City name is orumiyeh and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=orumiyeh.
    The City ID is 121801.
    ------------------------------------------------------------------------------------
    City #508.
    City name is limbang and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=limbang.
    The City ID is 1737714.
    ------------------------------------------------------------------------------------
    City #509.
    City name is gainesville and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=gainesville.
    The City ID is 4156404.
    ------------------------------------------------------------------------------------
    City #510.
    City name is pangody and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pangody.
    The City ID is 1495626.
    ------------------------------------------------------------------------------------
    City #511.
    City name is vao and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vao.
    The City ID is 588365.
    ------------------------------------------------------------------------------------
    City #512.
    City name is san luis and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=san luis.
    The City ID is 3837056.
    ------------------------------------------------------------------------------------
    City #513.
    City name is fort-shevchenko and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fort-shevchenko.
    The City ID is 609906.
    ------------------------------------------------------------------------------------
    City #514.
    City name is maniitsoq and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=maniitsoq.
    The City ID is 3421982.
    ------------------------------------------------------------------------------------
    City #515.
    City name is autlan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=autlan.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #516.
    City name is bowen and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bowen.
    The City ID is 2174444.
    ------------------------------------------------------------------------------------
    City #517.
    City name is botwood and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=botwood.
    The City ID is 5906229.
    ------------------------------------------------------------------------------------
    City #518.
    City name is santa cruz cabralia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=santa cruz cabralia.
    The City ID is 3450288.
    ------------------------------------------------------------------------------------
    City #519.
    City name is hit and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hit.
    The City ID is 95788.
    ------------------------------------------------------------------------------------
    City #520.
    City name is acapulco and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=acapulco.
    The City ID is 3533462.
    ------------------------------------------------------------------------------------
    City #521.
    City name is marawi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=marawi.
    The City ID is 1701054.
    ------------------------------------------------------------------------------------
    City #522.
    City name is buin and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=buin.
    The City ID is 3897774.
    ------------------------------------------------------------------------------------
    City #523.
    City name is vestmanna and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vestmanna.
    The City ID is 2610343.
    ------------------------------------------------------------------------------------
    City #524.
    City name is biu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=biu.
    The City ID is 2346995.
    ------------------------------------------------------------------------------------
    City #525.
    City name is gravdal and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=gravdal.
    The City ID is 3147822.
    ------------------------------------------------------------------------------------
    City #526.
    City name is sibu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sibu.
    The City ID is 1735902.
    ------------------------------------------------------------------------------------
    City #527.
    City name is itacoatiara and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=itacoatiara.
    The City ID is 3397893.
    ------------------------------------------------------------------------------------
    City #528.
    City name is port hedland and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=port hedland.
    The City ID is 2063042.
    ------------------------------------------------------------------------------------
    City #529.
    City name is mutsamudu and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mutsamudu.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #530.
    City name is odweyne and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=odweyne.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #531.
    City name is benguela and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=benguela.
    The City ID is 3351663.
    ------------------------------------------------------------------------------------
    City #532.
    City name is hualmay and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hualmay.
    The City ID is 3939761.
    ------------------------------------------------------------------------------------
    City #533.
    City name is manaus and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=manaus.
    The City ID is 3663517.
    ------------------------------------------------------------------------------------
    City #534.
    City name is axim and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=axim.
    The City ID is 2303611.
    ------------------------------------------------------------------------------------
    City #535.
    City name is souris and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=souris.
    The City ID is 6151455.
    ------------------------------------------------------------------------------------
    City #536.
    City name is katangli and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=katangli.
    The City ID is 2122783.
    ------------------------------------------------------------------------------------
    City #537.
    City name is gatesville and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=gatesville.
    The City ID is 4693150.
    ------------------------------------------------------------------------------------
    City #538.
    City name is kobryn and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kobryn.
    The City ID is 627145.
    ------------------------------------------------------------------------------------
    City #539.
    City name is roald and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=roald.
    The City ID is 3141667.
    ------------------------------------------------------------------------------------
    City #540.
    City name is keroka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=keroka.
    The City ID is 192869.
    ------------------------------------------------------------------------------------
    City #541.
    City name is vigrestad and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=vigrestad.
    The City ID is 3131824.
    ------------------------------------------------------------------------------------
    City #542.
    City name is cotonou and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=cotonou.
    The City ID is 2394819.
    ------------------------------------------------------------------------------------
    City #543.
    City name is mayahi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mayahi.
    The City ID is 2441194.
    ------------------------------------------------------------------------------------
    City #544.
    City name is broken hill and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=broken hill.
    The City ID is 2173911.
    ------------------------------------------------------------------------------------
    City #545.
    City name is nanortalik and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nanortalik.
    The City ID is 3421765.
    ------------------------------------------------------------------------------------
    City #546.
    City name is pundaguitan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=pundaguitan.
    The City ID is 1698289.
    ------------------------------------------------------------------------------------
    City #547.
    City name is turukhansk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=turukhansk.
    The City ID is 1488903.
    ------------------------------------------------------------------------------------
    City #548.
    City name is callaway and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=callaway.
    The City ID is 5024237.
    ------------------------------------------------------------------------------------
    City #549.
    City name is walvis bay and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=walvis bay.
    The City ID is 3359638.
    ------------------------------------------------------------------------------------
    City #550.
    City name is iquique and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=iquique.
    The City ID is 3887127.
    ------------------------------------------------------------------------------------
    City #551.
    City name is necochea and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=necochea.
    The City ID is 3430443.
    ------------------------------------------------------------------------------------
    City #552.
    City name is nizhniy baskunchak and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nizhniy baskunchak.
    The City ID is 520798.
    ------------------------------------------------------------------------------------
    City #553.
    City name is la ronge and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=la ronge.
    The City ID is 6050066.
    ------------------------------------------------------------------------------------
    City #554.
    City name is santana do livramento and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=santana do livramento.
    The City ID is 3449936.
    ------------------------------------------------------------------------------------
    City #555.
    City name is ransang and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ransang.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #556.
    City name is sisimiut and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sisimiut.
    The City ID is 3419842.
    ------------------------------------------------------------------------------------
    City #557.
    City name is olafsvik and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=olafsvik.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #558.
    City name is whitecourt and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=whitecourt.
    The City ID is 6180285.
    ------------------------------------------------------------------------------------
    City #559.
    City name is andenes and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=andenes.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #560.
    City name is fukue and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fukue.
    The City ID is 1848373.
    ------------------------------------------------------------------------------------
    City #561.
    City name is half moon bay and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=half moon bay.
    The City ID is 5354943.
    ------------------------------------------------------------------------------------
    City #562.
    City name is novomykolayivka and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=novomykolayivka.
    The City ID is 705811.
    ------------------------------------------------------------------------------------
    City #563.
    City name is sao joao da barra and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sao joao da barra.
    The City ID is 3448903.
    ------------------------------------------------------------------------------------
    City #564.
    City name is nabire and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nabire.
    The City ID is 1634614.
    ------------------------------------------------------------------------------------
    City #565.
    City name is ligayan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ligayan.
    The City ID is 1706466.
    ------------------------------------------------------------------------------------
    City #566.
    City name is deming and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=deming.
    The City ID is 5464806.
    ------------------------------------------------------------------------------------
    City #567.
    City name is bukachacha and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bukachacha.
    The City ID is 2026023.
    ------------------------------------------------------------------------------------
    City #568.
    City name is kodinsk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kodinsk.
    The City ID is 1503037.
    ------------------------------------------------------------------------------------
    City #569.
    City name is santiago del estero and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=santiago del estero.
    The City ID is 3835869.
    ------------------------------------------------------------------------------------
    City #570.
    City name is ales and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ales.
    The City ID is 3038224.
    ------------------------------------------------------------------------------------
    City #571.
    City name is ossora and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ossora.
    The City ID is 2122389.
    ------------------------------------------------------------------------------------
    City #572.
    City name is ambunti and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ambunti.
    The City ID is 2100933.
    ------------------------------------------------------------------------------------
    City #573.
    City name is khasan and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=khasan.
    The City ID is 2039557.
    ------------------------------------------------------------------------------------
    City #574.
    City name is gat and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=gat.
    The City ID is 2249901.
    ------------------------------------------------------------------------------------
    City #575.
    City name is ballina and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ballina.
    The City ID is 2966778.
    ------------------------------------------------------------------------------------
    City #576.
    City name is dharchula and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=dharchula.
    The City ID is 1272864.
    ------------------------------------------------------------------------------------
    City #577.
    City name is gazli and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=gazli.
    The City ID is 1513990.
    ------------------------------------------------------------------------------------
    City #578.
    City name is nanzhang and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nanzhang.
    The City ID is 1799574.
    ------------------------------------------------------------------------------------
    City #579.
    City name is yerbogachen and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=yerbogachen.
    The City ID is 2012956.
    ------------------------------------------------------------------------------------
    City #580.
    City name is mandera and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=mandera.
    The City ID is 187896.
    ------------------------------------------------------------------------------------
    City #581.
    City name is ylivieska and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ylivieska.
    The City ID is 630768.
    ------------------------------------------------------------------------------------
    City #582.
    City name is srikakulam and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=srikakulam.
    The City ID is 1255647.
    ------------------------------------------------------------------------------------
    City #583.
    City name is kanniyakumari and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kanniyakumari.
    The City ID is 1268008.
    ------------------------------------------------------------------------------------
    City #584.
    City name is krasnokamensk and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=krasnokamensk.
    The City ID is 2021618.
    ------------------------------------------------------------------------------------
    City #585.
    City name is fairview and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=fairview.
    The City ID is 5097801.
    ------------------------------------------------------------------------------------
    City #586.
    City name is verkhne-katunskoye and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=verkhne-katunskoye.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #587.
    City name is san jose and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=san jose.
    The City ID is 1689431.
    ------------------------------------------------------------------------------------
    City #588.
    City name is russkaya polyana and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=russkaya polyana.
    The City ID is 1493423.
    ------------------------------------------------------------------------------------
    City #589.
    City name is portland and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=portland.
    The City ID is 5746545.
    ------------------------------------------------------------------------------------
    City #590.
    City name is leon valley and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=leon valley.
    The City ID is 4705923.
    ------------------------------------------------------------------------------------
    City #591.
    City name is benton harbor and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=benton harbor.
    The City ID is 4985711.
    ------------------------------------------------------------------------------------
    City #592.
    City name is arrifes and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=arrifes.
    The City ID is 3373329.
    ------------------------------------------------------------------------------------
    City #593.
    City name is aldergrove and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=aldergrove.
    The City ID is 7669018.
    ------------------------------------------------------------------------------------
    City #594.
    City name is belaya gora and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=belaya gora.
    The City ID is 2126785.
    ------------------------------------------------------------------------------------
    City #595.
    City name is sungairaya and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=sungairaya.
    The City ID is 1625908.
    ------------------------------------------------------------------------------------
    City #596.
    City name is bosaso and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bosaso.
    The City ID is 64013.
    ------------------------------------------------------------------------------------
    City #597.
    City name is kemijarvi and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kemijarvi.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #598.
    City name is batagay-alyta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=batagay-alyta.
    The City ID is 2027042.
    ------------------------------------------------------------------------------------
    City #599.
    City name is wanaraja and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=wanaraja.
    The City ID is 1622138.
    ------------------------------------------------------------------------------------
    City #600.
    City name is svetlyy yar and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=svetlyy yar.
    The City ID is 485643.
    ------------------------------------------------------------------------------------
    City #601.
    City name is bonanza and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=bonanza.
    The City ID is 3620645.
    ------------------------------------------------------------------------------------
    City #602.
    City name is kohtla-jarve and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=kohtla-jarve.
    The City ID is 591260.
    ------------------------------------------------------------------------------------
    City #603.
    City name is badaojiang and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=badaojiang.
    This is not a city recognized in OpenWeatherMap.There will be no data for this city
    ------------------------------------------------------------------------------------
    City #604.
    City name is rincon and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=rincon.
    The City ID is 4218882.
    ------------------------------------------------------------------------------------
    City #605.
    City name is telsiai and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=telsiai.
    The City ID is 593926.
    ------------------------------------------------------------------------------------
    City #606.
    City name is changji and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=changji.
    The City ID is 1790885.
    ------------------------------------------------------------------------------------
    City #607.
    City name is saint-louis and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=saint-louis.
    The City ID is 2978742.
    ------------------------------------------------------------------------------------
    City #608.
    City name is constantine and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=constantine.
    The City ID is 2501152.
    ------------------------------------------------------------------------------------
    City #609.
    City name is ola and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=ola.
    The City ID is 2122574.
    ------------------------------------------------------------------------------------
    City #610.
    City name is raudeberg and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=raudeberg.
    The City ID is 3146487.
    ------------------------------------------------------------------------------------
    City #611.
    City name is nyrob and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nyrob.
    The City ID is 516588.
    ------------------------------------------------------------------------------------
    City #612.
    City name is nauta and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=nauta.
    The City ID is 3692020.
    ------------------------------------------------------------------------------------
    City #613.
    City name is hare bay and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=hare bay.
    The City ID is 5970873.
    ------------------------------------------------------------------------------------
    City #614.
    City name is quang ngai and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=quang ngai.
    The City ID is 1568770.
    ------------------------------------------------------------------------------------
    City #615.
    City name is amapa and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=amapa.
    The City ID is 3603330.
    ------------------------------------------------------------------------------------
    City #616.
    City name is halifax and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=halifax.
    The City ID is 6324729.
    ------------------------------------------------------------------------------------
    City #617.
    City name is tinsukia and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=tinsukia.
    The City ID is 1254432.
    ------------------------------------------------------------------------------------
    City #618.
    City name is moose factory and its url is http://api.openweathermap.org/data/2.5/weather?appid=074b0d7d1323371221cd9dce8e15094a&units=Imperial&q=moose factory.
    The City ID is 6078372.
    ------------------------------------------------------------------------------------
    


```python
#print head of datafram to verify it looks ok
citydata.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Longtitude</th>
      <th>Latitude</th>
      <th>Temperature</th>
      <th>Humidity</th>
      <th>Cloudiness</th>
      <th>Wind Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mataura</td>
      <td>168.86</td>
      <td>-46.19</td>
      <td>55.99</td>
      <td>71</td>
      <td>88</td>
      <td>5.39</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Jaciara</td>
      <td>-54.98</td>
      <td>-15.95</td>
      <td>73.72</td>
      <td>92</td>
      <td>8</td>
      <td>2.71</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Saint-Philippe</td>
      <td>-73.48</td>
      <td>45.36</td>
      <td>29.32</td>
      <td>79</td>
      <td>1</td>
      <td>8.05</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Torbay</td>
      <td>-52.73</td>
      <td>47.66</td>
      <td>30.20</td>
      <td>92</td>
      <td>90</td>
      <td>27.51</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Victoria</td>
      <td>115.24</td>
      <td>5.28</td>
      <td>89.60</td>
      <td>75</td>
      <td>75</td>
      <td>4.70</td>
    </tr>
  </tbody>
</table>
</div>



## Temp Vs Latitude


```python
#Temp vs Latitude Graph

#set x value as Latitude and y as Temperature. Then repeat with humidity, cloudiness and windspeed.

xvalue = citydata["Latitude"]
yvalue = citydata["Temperature"]

plt.title("Temperature Vs Latitude (%s)" % time.strftime("%x"))
plt.xlabel("Latitude")
plt.ylabel("Temperature in Farenheit")

plt.scatter(xvalue, yvalue, marker="o", color="red", edgecolor="black")
plt.savefig("Temp Vs Latitude.png")
plt.show()

```


![png](output_9_0.png)


# Humidity vs Latitude



```python
#Humidity vs Latitude Graph

xvalue = citydata["Latitude"]
yvalue = citydata["Humidity"]

plt.title("Humidity Vs Latitude (%s)" % time.strftime("%x"))
plt.xlabel("Latitude")
plt.ylabel("Humidity")

plt.scatter(xvalue, yvalue, marker="o", color="blue", edgecolor="black")
plt.savefig("Humidity Vs Latitude.png")
plt.show()

```


![png](output_11_0.png)


## Cloudiness vs Latitude


```python
#Cloudiness vs Latitude Graph
xvalue = citydata["Latitude"]
yvalue = citydata["Cloudiness"]

plt.title("Cloudiness vs Latitude (%s)" % time.strftime("%x"))
plt.xlabel("Latitude")
plt.ylabel("Cloudiness")

plt.scatter(xvalue, yvalue, marker="o", color="green", edgecolor="black")
plt.savefig("Cloudiness Vs Latitude.png")
plt.show()


```


![png](output_13_0.png)


## Wind Speed vs Latitude


```python
#Wind Speed vs Latitude Graph
xvalue = citydata["Latitude"]
yvalue = citydata["Wind Speed"]

plt.title("Wind Speed (mph) Vs Latitude (%s)" % time.strftime("%x"))
plt.xlabel("Latitude")
plt.ylabel("Wind Speed")

plt.scatter(xvalue, yvalue, marker="o", color="orange", edgecolor="black")
plt.savefig("Wind Speed in mph Vs Latitude.png")
plt.show()


```


![png](output_15_0.png)


## Analysis


```python
#There appears to be a strong relationship between Temperature and distance from the equator. The farther one is away from
#the equator (Lat= 0), the colder it gets


#There doesnt seem to be a very strong correlation with Wind Speed or Cloudiness with Latitude
#There appears to be more cities in the Northern Hemisphere than Southern.
```
